# Explainability Boundaries: A Synthetic Audit Suite

A small, reproducible research artifact for studying what an explanation can substantiate at different stages of a decision pipeline. The suite separates source identity, source grounding, faithful execution of a rule, attribution of the final action, and stability across declared alternative inputs.

**Release 1.2.2:** the original main corpus remains unchanged at 100 constructed episodes, 700 claim labels, and 20 scenario families (corpus version 1.0.0). A separate diagnostic extension adds eight episodes and 56 claims in four paired constructions; it is reported separately and is not pooled with the main corpus. All merchants, source documents, transaction summaries, rules, and interventions are fictional. The underlying records are controlled fault-injection and conformance cases, not real banking records or observed model extractions. Release 1.2.0 added a separately reported tool-assisted assistant audit pilot over the 60 main reporting episodes and eight diagnostics, plus a paired image-source audit of 12 main episodes. Saved assistant audit outputs are distinguished from the original deterministic checker outputs.

The core checker and offline scorer use Python 3.10 or later and the standard library. Reproducing scores from the supplied data and saved responses requires no network, credentials, or model service. Repeating live assistant inference is a separate operation and is not guaranteed to reproduce identical responses.

## Reproduce

Extract or clone the repository, change into its root directory, then run:

```sh
python -m boundarybench validate --data-dir data
python -m unittest discover -s tests -v
python -m boundarybench reproduce --output results
```

Use `python3` instead of `python` if that is your system's Python 3 command. The reproduction command evaluates all three capability ablations and writes the original main-corpus reports under `results/`, plus separate extension reports under `results/diagnostics/`. With the released pilot inputs and saved responses present, it also rescores the archived assistant run under `results/pilot/`; it makes no live model call. It also regenerates provenance-labelled cross-run reporting in `results/models/` when the comparison inputs are present. To run only the extension:

```sh
python -m boundarybench diagnostics --data-dir data/diagnostics --output results/diagnostics
```

To regenerate the corpus independently:

```sh
python scripts/generate_data.py --output regenerated-data
python -m boundarybench validate --data-dir regenerated-data
python -m boundarybench reproduce --data-dir regenerated-data --output regenerated-results
```

Generation is deterministic. Identical generator code and configuration produce the same main-corpus and diagnostic files. This corpus generator does not recreate assistant responses or source-card exports; use the separate commands in [PILOT.md](docs/PILOT.md) for the pilot. The included GitHub Actions workflow checks regeneration and the test suite on Python 3.10, 3.12, and 3.13; the workflow itself uses GitHub-hosted infrastructure, whereas the local commands run offline.

## Contents

| Path | Purpose |
|---|---|
| `data/cases.jsonl` | Observable fictional sources, recorded decisions, and seven claims per episode |
| `data/reference.jsonl` | Construction reference labels and rationales; used only by scoring |
| `data/metadata.json` | Scenario-family, split, variant, and subtype metadata |
| `data/diagnostics/` | Separate eight-episode extension, references, metadata, and integrity manifest |
| `data/pilot/` | Fixed assistant prompts, batches, source cards, selection/join metadata, and integrity manifest |
| `boundarybench/` | Deterministic checker, scoring, validation, and command-line entry points |
| `scripts/generate_data.py` | Regenerates the released data |
| `tests/` | Regression, boundary-condition, and integrity checks |
| `docs/CONTRACT.md` | Exact record and claim semantics |
| `docs/PROTOCOL.md` | Evaluation design, metrics, and interpretation |
| `docs/EXTERNAL_MODELS.md` | Optional audit prompts and scoring format for future model runs |
| `docs/RESULTS_FOR_PAPER.md` | Suggested reporting paragraph and qualified result table |
| `results/` | Original main-corpus predictions, detailed metrics, and a readable report |
| `results/diagnostics/` | Separate diagnostic predictions and reports; excluded from main totals |
| `results/pilot/` | Archived assistant responses, run metadata, and separately scored pilot reports |
| `results/models/` | Provenance-labelled cross-run reporting; not a matched ranking |
| `results/external/grok-4.7/` | Supplied report, predictions and protocol materials, plus local rescoring evidence |
| `results/external/claude-fable-5.1/` | Supplied report and bundle, audit/extraction responses and prompts, and local scoring evidence |
| `docs/PILOT.md` | Pilot task, fixed inputs, tool assistance, model disclosure, and limitations |
| `docs/CLAUDE_EVALUATION.md` | Claude tool conditions, failure analysis, source-only extraction, and quote-check definitions |
| `docs/PUBLIC_RELEASE.md` | Artifact scope and publication checklist |

The data files have different roles deliberately. Inference receives the observable episode; it does not receive the reference labels, split/variant metadata, subject, or case ID as decision features. The scorer associates predictions with labels afterwards. This separation is an implementation property, not a claim that public labels are secret.

## What is being tested?

Episodes contain fictional source evidence, extracted numerical inputs, a threshold-rule execution record, and claims about the record; selected variants deliberately omit a contract or transaction summary. The toy policy refers a case for manual review when its recorded dispute fraction is at least 1/50 or its recorded penalty-free commitment is below six months. These thresholds exist solely to make the experiment inspectable; they are not recommended financial or regulatory policy.

Each of 20 families has five variants: clean evidence, an injected extraction error, a source gap, an ambiguous interpretation, and an intervention/history issue. The seven claims are scored as `supported`, `contradicted`, or `unresolved`. An incorrect extraction can coexist with faithful execution on the recorded input. Likewise, matching rule and final outputs do not establish that no human intervention occurred.

| Checker | Enabled capabilities |
|---|---|
| `execution_only` | Checks conditional execution, final-action attribution, declared-candidate stability, and a conditional sufficient reason |
| `provenance` | Adds source identity, version, and byte-digest checks |
| `boundary` | Also checks source grounding within the documented source language |

All three receive the same observable sources. Capabilities are disabled conservatively: unavailable checks yield `unresolved`, not guessed conclusions. They are ablations of one reference implementation, not separately trained competitors. Higher resolution from an enabled checker demonstrates what that implementation checks on these fixtures; it does not establish a general advantage over other systems.

## Saved GPT-6.1 Sol Ultra pilot

The pilot asks **GPT-6.1 Sol Ultra** to audit seven existing claims per episode.
That exact display name was supplied by the user on 2026-10-04 after the run;
it does not supply an immutable API snapshot or sampling configuration. Frozen
inputs retain their historical Codex/GPT-6 labels for provenance. Renaming the
display identity does not change the saved responses or rerun inference. It
uses four fresh text contexts of 17 episodes, covering the main reporting
partition (60 episodes, 420 claims) and diagnostics (eight episodes, 56 claims).
A separate image condition presents the same source text as PNG cards for 12
main episodes (84 claims). Its matched text control uses separate fresh runs
with identical case order: two six-episode batches per condition, rather than
reusing the primary 17-episode-batch responses.
These are not new or independently sampled datasets.

A deterministic frontend supplies citation presence, kind, version, and SHA-256
observations. It supplies no semantic label or policy result. The assistant
assigns all seven labels using a fixed task prompt, without supplied reference labels or
checker outputs; the inference protocol prohibits reading answer-key or checker
files. The authoring assistant and evaluation
assistant share the same model context of use and synthetic protocol; fresh
contexts do not make this independent external validation. The exact model
snapshot and sampling settings are not exposed by the execution environment.

The archive preserves task instructions, structured raw responses, citation
integrity observations, worker-reported activity logs, selection metadata, and
hashes. Activity logs are self-reports, not independently audited complete tool
traces. Inputs and outputs are
frozen before scoring. [PILOT.md](docs/PILOT.md) explains how to rescore the
saved run and what can be inferred from it. This GPT pilot is a source-backed
claim-audit task; its source-only extraction, causal actionability, fairness,
compliance, and human review benefits are not evaluated. A separate Claude
extraction task is described below.

The saved pilot achieved failure-adjusted label agreement of **420/420** on
the main reporting partition and **56/56** on diagnostics. Matched text and
image conditions each agreed on **84/84** claims, with no paired label
differences. No batch conversion failures occurred. Main predictions comprised
333 supported, 55 contradicted, and 32 unresolved labels; matched conditions
each comprised 68 supported, seven contradicted, and nine unresolved. These
figures describe this authored, tool-assisted run, not independent model
validation or performance on natural financial documents. See
[the full reporting note](docs/RESULTS_FOR_PAPER.md) for scope-specific counts.

## Supplied comparison runs

Release 1.2.2 archives supplied Grok 4.7 predictions and Claude Fable 5.1 audit
and extraction outputs. Local audit rescoring gives:

| Supplied condition | Main agreement | Main resolved | Main false support / endorsements | Diagnostic agreement | Diagnostic resolved | Diagnostic false support / endorsements |
|---|---:|---:|---:|---:|---:|---:|
| Grok 4.7 | 420/420 | 388/420 | 0/333 | 56/56 | 48/56 | 0/36 |
| Claude Fable 5.1 — no computational tools | 359/420 | 331/420 | 2/277 | 43/56 | 35/56 | 0/23 |
| Claude Fable 5.1 — hash and arithmetic tools | 420/420 | 388/420 | 0/333 | 56/56 | 48/56 | 0/36 |

The 32 reference-unresolved main claims are expected abstentions due to the
available evidence, not missing responses. Claude's no-computation condition
adds capability-related abstentions and two false supports on invalid contract
citations. Its separately supplied source-only extraction outputs have all
55 target fields correct across 25 documents in each text and rendered-image
condition. The documents are synthetic templates with mild image degradation;
these results do not establish extraction performance on real documents or
end-to-end decision quality. See [CLAUDE_EVALUATION.md](docs/CLAUDE_EVALUATION.md)
for the failure analysis and separate exact/normalized quote checks.

Grok's supplied run card describes uniform tool-assisted session judgement,
not a sampled API decode, with hash checks and exact policy replay. The report
declares single-case calls. GPT-6.1 Sol Ultra used an integrity-only frontend,
four primary 17-case contexts, and two six-case contexts per paired condition.
Execution provenance and differing tools/context prevent treating these
separate runs as a matched model ranking. Claude's configured model identity,
fresh contexts, and instruction-based tool restrictions are provider reports;
complete model-call traces are not independently verified. Differences between
its two runs do not isolate a causal tool effect. See
[MODEL_COMPARISON.md](docs/MODEL_COMPARISON.md).

To rescore the supplied external files and regenerate this reporting independently:

```sh
python -m boundarybench.comparison
```

The command writes `results/models/comparison.json` and `comparison.md`, with
external scoring reports under the respective `results/external/` directories. It makes no
model call; the original report, supplied files, and their hashes are retained.

## Individual runs and further model predictions

```sh
python -m boundarybench audit --cases data/cases.jsonl --method boundary --output predictions.jsonl
python -m boundarybench score --predictions predictions.jsonl --reference data/reference.jsonl --metadata data/metadata.json --output scored
```

Change `--method` to `execution_only` or `provenance` for the other ablations. Consult `python -m boundarybench --help` and the subcommand help for available options and output details.

For a later model-based audit experiment, export prompts from the reporting partition (whose legacy format identifier is `test`):

```sh
python -m boundarybench export-prompts --output model-inputs.jsonl --split test
```

Exporting prompts makes no model call. Any later experiment must record the model/version, complete prompt, parameters, raw response, response-processing code, errors, and run date separately. Do not describe the bundled injected extraction values as model outputs. Prompt exports support an audit task over the supplied record; studying extraction itself requires a separate extractor protocol that withholds the recorded extraction and reference answers.

See [the further-model protocol](docs/EXTERNAL_MODELS.md) for additional runs and [the saved pilot protocol](docs/PILOT.md) for the distinct archived assistant response format, tool observations, and scoring commands.

## Interpretation and limitations

The first eight families are the development partition (`dev`) and the remaining twelve are the reporting partition (`test`). The legacy identifiers are retained for format compatibility. Both partitions are public conformance fixtures and were inspected during implementation. Keeping variants of a family together does not provide a blind test, unseen templates, or evidence of generalisation. The main corpus has 20 constructed families, not 100 independent real-world observations. Reference labels are produced by explicit construction; no independent human labelling or inter-annotator agreement is claimed.

Report accuracy, the full three-class confusion matrices, resolution coverage, and false support together. An abstaining checker can avoid false endorsements while resolving nothing. Report results separately by claim kind and split, and use scenario families as the unit when describing variation. Fault frequencies are design choices; they do not estimate deployment prevalence.

The source parser recognizes a bounded fixture language. Byte hashes establish agreement with retained bytes, not source authenticity or truth. Conditional trace faithfulness does not establish correct extraction. Candidate stability is conditional on the supplied alternatives and fixed remaining inputs; it is neither exhaustive robustness nor a causal claim. Complete action histories are stipulated fixture properties. Fairness, causal effects, operational benefits, review-time savings, and real-world error rates remain untested.

The original parameter grid uses five source count pairs, six commitment values, three framework durations, three contract templates, and one observation window; [the dataset card](docs/DATASET.md) lists the exact values and 14 non-clean subtypes. Only four of 20 injected extraction errors change the recommendation relative to the clean counterpart, including two of twelve in the reporting partition. Trace faults flip only the recorded commitment predicate. This is narrow fault coverage.

The diagnostic extension fixes the dispute fraction below threshold and varies declared candidate commitments across `{6,9}`, `{3,5}`, `{3,6,9}`, and `{6,9,12}`. Each set has paired positive and negative stability assertions. It demonstrates that candidate stability and a sufficient dispute reason are different propositions, and that the checker honours Boolean assertions. These are additional authored conformance checks, not independent validation.

The checker evaluates structured claim kinds and asserted values; it does not validate whether arbitrary explanation prose agrees with those fields. The provided claim text is a rendering of the structured proposition.

## Licence and citation

The source code, documentation, and fictional dataset are released under the [MIT License](LICENSE). `CITATION.cff` contains generic collective attribution for this anonymous research supplement. Add the final author list and permanent repository/archive identifiers when appropriate; no DOI or publication acceptance is asserted.

Before linking a public repository from a double-blind submission, check the venue's anonymity requirements: the hosting account and commit metadata can disclose authorship even when the files are anonymous. See [the release notes](docs/PUBLIC_RELEASE.md).
