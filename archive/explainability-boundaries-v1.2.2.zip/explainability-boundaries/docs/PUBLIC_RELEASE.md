# Public release notes

Release 1.2.2 is an anonymous research supplement prepared for public redistribution. It preserves the original main corpus (version 1.0.0) and retains a separately reported diagnostic extension. It also archives an assistant audit pilot and paired text/image source presentations. Its scope is newly constructed fictional text, numerical fixtures, an elementary threshold policy, generic audit code, tests, and reproduction documentation. It does not require organizational services, credentials, customer records, internal repositories, model weights, or private product components.

## Included material

- The unchanged main corpus: 100 fictional episodes, 700 claims, and 20 families.
- A separate diagnostic extension: eight episodes, 56 claims, and four paired constructions, with its own manifest and reports.
- Separate deterministic reference labels, rationales, and family/split metadata.
- Source code for generation, validation, audit, scoring, and prompt export.
- Pilot task instructions, fixed source presentations, citation-integrity observations, emitted structured responses, run metadata, and separate scores.
- Tests and a GitHub Actions workflow.
- A supplied Grok 4.7 aggregate report, subsequently supplied predictions/protocol materials, and local rescoring evidence.
- Claude Fable 5.1 audit runs with and without computational tools, plus separate text and rendered-image extraction responses, prompts, source images, and scoring evidence. Original supplied archives and historical pending metadata are retained.
- A user-supplied display-identity correction to GPT-6.1 Sol Ultra; frozen inputs and responses retain their original provenance.
- Protocol documentation, an MIT licence, and generic citation metadata.

This is a prepared release artifact, not evidence that a repository has been published or a paper accepted. The licence covers this code, documentation, and fictional dataset. The collective copyright label is generic; publication owners should supply appropriate final attribution when anonymity no longer applies.

## Release checklist

Before publication, verify the actual files being uploaded:

- [ ] Run dataset validation, tests, deterministic regeneration, and reproduction from a fresh copy.
- [ ] Inspect the archive/repository manifest; include only the intended package files.
- [ ] Check for credentials, local configuration, personal contact information, absolute workstation paths, real customer or merchant records, internal URLs, private model names, and organization-specific material.
- [ ] Keep assistant/model responses clearly distinguished from the synthetic source fixtures and deliberately injected extraction values.
- [ ] Review pilot task/tool records before redistribution: retain the public experiment evidence, exclude credentials and unrelated session content, and disclose any omitted runtime information. Do not imply that hidden system instructions or private reasoning were archived.
- [ ] Distinguish offline rescoring from live inference and retain unknown model-snapshot/sampling fields as unknown, rather than inventing them.
- [ ] Ensure numerical findings quoted in the paper match a preserved run and the stated corpus version.
- [ ] Retain the limitations: constructed reference labels, bounded source language, narrow parameter grid and fault model, dependent cases, public development/reporting fixtures, and no deployment-rate estimates.
- [ ] Report the diagnostic extension separately; do not pool its 56 claims into the original 700-claim main corpus or describe it as external validation.
- [ ] Review hosting-account identity, commit author/email metadata, README links, and issue history against the submission's double-blind requirements.
- [ ] Set final attribution and permanent repository/archive identifiers after anonymous review if needed; do not insert an unassigned DOI.

The repository's contents and provenance should be assessed directly. These notes are a scope statement and checklist, not an independent confidentiality, legal, or security certification.

## Anonymous submission

Removing names from files does not anonymize a personally or corporately hosted repository. Use a venue-permitted anonymous supplement or anonymous artifact link while review remains double blind. No publishing or submission operation is performed by the local commands in this package.

## Future contributions

Contributions should use invented or explicitly licensed public material and include the relevant provenance. Do not add confidential datasets, internal implementation details, or credentials. Changes to source semantics, reference labels, templates, or scoring should increment the corpus/protocol version and preserve enough information to reproduce earlier reported results.
