# Suggested reporting text — release 1.2.2

The first paragraph and tables describe the deterministic conformance implementation. Later sections distinguish the archived GPT-6.1 Sol Ultra audit pilot from locally rescored supplied prediction files and their execution-provenance limits. Deterministic results alone are not measured model performance; none of these runs establishes deployment effectiveness.

> We operationalized the proposed evidence distinctions in a public synthetic conformance suite containing 100 decision episodes from 20 scenario families, with seven claims per episode. Reference labels were assigned by construction and kept separate from checker inputs. On the public constructed reporting partition (legacy identifier `test`) (60 episodes, 12 families, 420 claims), the bounded checker agreed with 418 reference labels (99.52%) and resolved 386 claims (91.90%). Its two disagreements were conservative abstentions on human-interpretable worded-number passages outside its documented parser language. No false support occurred among its 331 endorsements on this partition. Enabling source-identity checks increased resolution coverage from 55.24% to 69.05%; additionally enabling bounded grounding checks increased it to 91.90%. These are capability ablations of one implementation, not competitive model comparisons. The results demonstrate conformance to the defined claim scopes on controlled cases; they do not establish general natural-language verification, unseen-model performance or real-world error rates.

| Capability ablation | Reference agreement | Resolved claims | False support / endorsements |
|---|---:|---:|---:|
| Execution only | 264/420 (62.86%) | 232/420 (55.24%) | 0/193 |
| With source identity | 322/420 (76.67%) | 290/420 (69.05%) | 0/247 |
| With bounded grounding | 418/420 (99.52%) | 386/420 (91.90%) | 0/331 |

The lower-resolution ablations conservatively abstain on disabled checks. The table therefore describes the contribution of implemented capabilities, not a fair contest between equal-capability systems. Variants and claims share family structure; the 420 claims are not independent population observations. Both the development and reporting partitions were inspected during implementation and software validation; `dev` and `test` are legacy format identifiers, not evidence of blind testing. Zero observed false endorsements is not a guarantee for unseen cases.

The main fixture grid has only five source count pairs, six commitment values, three framework durations, three literal contract templates, and one observation window. Its 14 non-clean subtypes form a narrow fault model. Trace faults flip only the commitment predicate. Four of twenty injected extraction errors change the recommendation relative to the clean counterpart, including two of twelve in the reporting partition. These counts constrain what the main results demonstrate.

## Separately reported diagnostic extension

Release 1.1.0 added eight episodes (56 claims) in four paired diagnostic constructions. At fixed dispute counts 25/1500, candidate sets `{6,9}`, `{3,5}`, and `{6,9,12}` produce stable recommendations, while `{3,6,9}` does not. Every set is tested with c6 asserting both true and false. Claim c7 positively asserts a sufficient dispute reason and is contradicted throughout. Thus candidate stability cannot be replaced by the dispute predicate, and assertion polarity must be checked. These are authored logical diagnostics addressing a known construction limitation. The original deterministic results below are distinct from the later assistant audits and do not provide external validation. Do not merge their totals with the main table. The generated diagnostic report records the following separate results:

| Capability ablation | Reference agreement | Resolved claims | False support / endorsements |
|---|---:|---:|---:|
| Execution only | 40/56 (71.43%) | 32/56 (57.14%) | 0/20 |
| With source identity | 48/56 (85.71%) | 40/56 (71.43%) | 0/28 |
| With bounded grounding | 56/56 (100%) | 48/56 (85.71%) | 0/36 |

All methods correctly evaluate c6 on all eight diagnostic episodes (four
supported and four contradicted assertions) and c7 on all eight (contradicted).
The complete reference distribution is 36 supported, 12 contradicted, and eight
unresolved. The eight unresolved labels concern commitment grounding: the
retained contracts specify different commitments with no source-precedence
rule. This does not prevent checking stability over the declared candidates.
Full results are in `results/diagnostics/summary.json`. Agreement here is
conformance to an authored diagnostic design and adds no population or
out-of-distribution guarantee.

## Archived GPT-6.1 Sol Ultra audit pilot

> We also conducted a tool-assisted, author-associated GPT-6.1 Sol Ultra audit pilot using fixed prompts and fresh batch contexts. Four 17-episode text batches covered 60 main reporting episodes and eight diagnostics, which were scored separately. A deterministic frontend supplied citation presence, kind, version and SHA-256 observations, but no semantic labels or computed policy recommendations. The assistant agreed with all 420 main and all 56 diagnostic construction labels. Separate matched text and image-source runs used the same 12 main episodes in two six-episode batches per condition and each agreed with all 84 labels, with no paired label disagreements. No batch conversion failures occurred. These observations concern seven-claim audits over existing synthetic records; they do not measure source-only extraction. The same assistant environment participated in authoring and evaluation, exact model snapshot and sampling settings were unavailable, and activity logs were worker self-reports rather than independently audited complete traces. The pilot therefore provides an archived demonstration on these fixtures, not independent validation or deployment evidence.

| Assistant condition | Primary failure-adjusted agreement | Resolved claims | False support / endorsements |
|---|---:|---:|---:|
| Main reporting text | 420/420 (100%) | 388/420 (92.38%) | 0/333 |
| Diagnostic text | 56/56 (100%) | 48/56 (85.71%) | 0/36 |
| Matched paired text | 84/84 (100%) | 75/84 (89.29%) | 0/68 |
| Paired image sources | 84/84 (100%) | 75/84 (89.29%) | 0/68 |

Main predicted/reference labels comprise 333 supported, 55 contradicted, and 32
unresolved. Diagnostics comprise 36 supported, 12 contradicted, and eight
unresolved. Each paired condition comprises 68 supported, seven contradicted,
and nine unresolved. These denominators are separate; paired cases repeat main
cases and must not be pooled into a larger independent sample.

| Assistant condition | Lineage c1 | Remaining six scopes | Source grounding c2–c3 (included within six scopes) |
|---|---:|---:|---:|
| Main reporting text | 60/60 | 360/360 | 120/120 |
| Diagnostic text | 8/8 | 48/48 | 16/16 |
| Matched paired text | 12/12 | 72/72 | 24/24 |
| Paired image sources | 12/12 | 72/72 | 24/24 |

Lineage is reported separately because the integrity frontend assists it.
All seven labels are emitted by the assistant; integrity observations must not
be described as unaided model hash verification. Primary failure-adjusted
agreement would count every claim in a missing/malformed batch as wrong,
including a reference-unresolved claim. Ordinary label agreement is secondary;
it happens to be equal here because zero batches failed conversion.

The two deliberately spelled-out eighteen-month commitment claims in the main
reporting partition were supported correctly (2/2), whereas the bounded
reference checker abstained on them. This small designed subgroup illustrates a
capability difference on those passages; it does not show broad linguistic
superiority. The paired image audit uses rendered versions of the same short
text, not natural scans or independent multimodal data. There were zero paired
label differences. Free-text reasons and evidence statements were retained but
not independently adjudicated.

The pilot's raw outputs, task instructions, citation observations, worker
self-reports, run metadata, manifests, and scoring outputs are archived under
`data/pilot/` and `results/pilot/`. Offline rescoring reproduces the archived
run's metrics; live inference is not guaranteed to be bit-identical. No causal
actionability, fairness, regulatory compliance, or human review benefit was
evaluated.

## Supplied Grok predictions

Following an initial aggregate report, the user supplied Grok 4.7 claim-level
predictions and protocol materials. Local rescoring with the existing scorer
confirms 420/420 main reporting agreement, 388/420 resolved claims, and zero
false support among 333 endorsements. Diagnostics separately give 56/56
agreement, 48/56 resolved, and zero false support among 36 endorsements. The
last two diagnostic denominators are computed from the subsequently supplied
predictions; they were absent from the original aggregate report. Preserve
that report and the newly supplied files unchanged.

The evidence status is `supplied_predictions_locally_rescored`. It validates
these label metrics, not independently verified live Grok inference. The
supplied system card describes uniform tool-assisted session judgement rather
than a sampled API decode; immutable model identity and native call traces are
not supplied. Its exact-replay assistance and declared single-case calls differ
from the GPT integrity-only frontend and batched contexts. This is a separate
run with uncertain execution provenance, not a matched ranking of models.

The generated report in `results/models/` retains these evidence distinctions.
Grok has no supplied paired image/text run.

The GPT and Grok sets support the two spelled-out eighteen-month grounding
claims. That is source-grounding audit evidence, not extraction-integration
or unaided foundation-model performance. Broader interpretations in the Grok
report remain attributed to their source rather than adopted here.

The GPT display name, **GPT-6.1 Sol Ultra**, was supplied by the user on
2026-10-04 after the archived run. Frozen Codex/GPT-6 input labels are retained
as historical provenance. The correction did not rerun inference or change
responses; immutable model snapshot and sampling settings remain unknown.
See [MODEL_COMPARISON.md](MODEL_COMPARISON.md) for the full status table.

## Supplied Claude audit and extraction results

The supplied Claude Fable 5.1 audit responses were locally converted and
rescored. Report the two tool conditions separately:

| Condition | Main agreement | Main resolved | Main false support / endorsements | Diagnostic agreement | Diagnostic resolved | Diagnostic false support / endorsements |
|---|---:|---:|---:|---:|---:|---:|
| No computational tools | 359/420 | 331/420 | 2/277 | 43/56 | 35/56 | 0/23 |
| SHA-256 and integer-arithmetic tools | 420/420 | 388/420 | 0/333 | 56/56 | 48/56 | 0/36 |

The main no-computation disagreements comprise 54 supported-to-unresolved
lineage claims, one contradicted-to-unresolved lineage claim, four
supported-to-unresolved dispute-grounding claims, and two
unresolved-to-supported commitment-grounding claims. The last two are false
supports on invalid contract citations. Capability-related abstention is
prudent when a required digest cannot be checked; correct grounding labels
accepted without the prerequisite check do not establish verified grounding.
Local hashing confirms the invalid citations; an all-zero-looking digest
alone is not proof of a mismatch.
The diagnostic disagreements are eight lineage and five dispute-grounding
abstentions. Differences between these runs do not isolate a causal effect
of hashing: arithmetic permission also differs, and there is one supplied
run per condition. No general conclusion about a semantic-reasoning bottleneck
follows.

The 32 unresolved main reference labels are expected answers, not missing
responses or model failures:

| Scope | Count | Reason |
|---|---:|---|
| Commitment grounding | 20 | 14 conflicting contracts, four invalid citations, two missing contracts |
| Final-action attribution | 6 | Three incomplete histories, three inconsistent traces |
| Contract lineage | 2 | Missing contracts |
| Dispute grounding | 2 | Missing transaction sources |
| Candidate stability | 2 | Empty candidate sets |

Conditional execution and sufficient dispute reason have no unresolved main
reference labels. Additional no-computation abstentions are capability-limited
predictions and must not be conflated with this reference breakdown.

Claude's separate text and mildly degraded rendered-image extraction runs each
recover all 55 target fields from 25 synthetic documents (20 contracts and
five transaction summaries). This is a source-only extraction task on the
existing templates; it is not an integrated extraction-to-decision evaluation.
Exact-character quote matches are 20/25 for text and 21/25 for image.
Whitespace-normalized matches are 25/25 and 24/25; those latter counts were
described as exact in the supplied report. Preserve that report unchanged and
use the corrected definitions when reporting current results.

The provider reports fresh per-call agents, one attempt, default sampling,
instruction-based tool restrictions, and an operator who had already seen the
answer key and checker. The configured `claude-fable-5-1` identity is not
attested because harness fallback is possible. Local checks verify prompt
hashes, raw-to-prediction conversion, and scoring, not runtime identity,
tool execution, or reference isolation. These outputs are evidence on the
released fixtures with stated provenance, not a matched ranking against GPT
or Grok or independent deployment validation. See
[CLAUDE_EVALUATION.md](CLAUDE_EVALUATION.md).

Use release/code version 1.2.2, preserved main-corpus version 1.0.0, dataset digests in `data/manifest.json`, and the full `results/summary.json` for main deterministic results. For assistant results also retain `data/pilot/manifest.json`, `results/pilot/model_run.json`, the frozen response manifest, and `results/pilot/summary.json`. Full class confusion matrices, claim-kind results and family summaries accompany the aggregate table. Add the actual public repository or archive URL only after publication; no repository has been published by this package.
